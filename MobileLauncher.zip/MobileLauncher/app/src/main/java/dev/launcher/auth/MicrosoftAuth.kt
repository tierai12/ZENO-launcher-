package dev.launcher.auth

import dev.launcher.core.MojangApi
import kotlinx.coroutines.delay
import kotlinx.serialization.json.*
import okhttp3.FormBody
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody

/** Register your own Azure app (public client, "Allow public client flows" ON) and paste its ID here. */
const val CLIENT_ID = "YOUR-AZURE-APP-CLIENT-ID"

data class DeviceCode(val userCode: String, val deviceCode: String, val verificationUri: String, val interval: Int, val expiresIn: Int)
data class McSession(val name: String, val uuid: String, val accessToken: String, val msRefreshToken: String?)

object MicrosoftAuth {
    private val JSON_MT = "application/json".toMediaType()
    private const val TENANT = "https://login.microsoftonline.com/consumers/oauth2/v2.0"
    private const val SCOPE = "XboxLive.signin offline_access"

    private fun postForm(url: String, vararg f: Pair<String, String>): JsonObject {
        val body = FormBody.Builder().apply { f.forEach { add(it.first, it.second) } }.build()
        MojangApi.http.newCall(Request.Builder().url(url).post(body).build()).execute().use {
            return Json.parseToJsonElement(it.body!!.string()).jsonObject
        }
    }

    private fun postJson(url: String, payload: JsonObject, bearer: String? = null): JsonObject {
        val req = Request.Builder().url(url).post(payload.toString().toRequestBody(JSON_MT))
            .header("Accept", "application/json").apply { bearer?.let { header("Authorization", "Bearer $it") } }.build()
        MojangApi.http.newCall(req).execute().use { r ->
            val text = r.body!!.string()
            check(r.isSuccessful) { "HTTP ${r.code} from $url: $text" }
            return Json.parseToJsonElement(text).jsonObject
        }
    }

    fun requestDeviceCode(): DeviceCode {
        val o = postForm("$TENANT/devicecode", "client_id" to CLIENT_ID, "scope" to SCOPE)
        return DeviceCode(
            o["user_code"]!!.jsonPrimitive.content, o["device_code"]!!.jsonPrimitive.content,
            o["verification_uri"]!!.jsonPrimitive.content, o["interval"]!!.jsonPrimitive.int, o["expires_in"]!!.jsonPrimitive.int,
        )
    }

    /** Polls until the user finishes signing in, then runs the Xbox -> XSTS -> Minecraft chain. */
    suspend fun signIn(dc: DeviceCode): McSession {
        var waited = 0
        var ms: JsonObject
        while (true) {
            ms = postForm("$TENANT/token",
                "grant_type" to "urn:ietf:params:oauth:grant-type:device_code",
                "client_id" to CLIENT_ID, "device_code" to dc.deviceCode)
            if ("access_token" in ms) break
            val err = ms["error"]?.jsonPrimitive?.content
            check(err == "authorization_pending" || err == "slow_down") { "Sign-in failed: $err" }
            check(waited < dc.expiresIn) { "Code expired" }
            delay(dc.interval * 1000L); waited += dc.interval
        }
        return exchange(ms["access_token"]!!.jsonPrimitive.content, ms["refresh_token"]?.jsonPrimitive?.content)
    }

    /** Silent re-login using a stored refresh token. */
    fun refresh(refreshToken: String): McSession {
        val ms = postForm("$TENANT/token", "grant_type" to "refresh_token",
            "client_id" to CLIENT_ID, "refresh_token" to refreshToken, "scope" to SCOPE)
        return exchange(ms["access_token"]!!.jsonPrimitive.content, ms["refresh_token"]?.jsonPrimitive?.content)
    }

    private fun exchange(msToken: String, refresh: String?): McSession {
        val xbl = postJson("https://user.auth.xboxlive.com/user/authenticate", buildJsonObject {
            putJsonObject("Properties") {
                put("AuthMethod", "RPS"); put("SiteName", "user.auth.xboxlive.com"); put("RpsTicket", "d=$msToken")
            }
            put("RelyingParty", "http://auth.xboxlive.com"); put("TokenType", "JWT")
        })
        val xblToken = xbl["Token"]!!.jsonPrimitive.content

        val xsts = postJson("https://xsts.auth.xboxlive.com/xsts/authorize", buildJsonObject {
            putJsonObject("Properties") {
                put("SandboxId", "RETAIL"); putJsonArray("UserTokens") { add(xblToken) }
            }
            put("RelyingParty", "rp://api.minecraftservices.com/"); put("TokenType", "JWT")
        })
        val xstsToken = xsts["Token"]!!.jsonPrimitive.content
        val uhs = xsts["DisplayClaims"]!!.jsonObject["xui"]!!.jsonArray[0].jsonObject["uhs"]!!.jsonPrimitive.content

        val mc = postJson("https://api.minecraftservices.com/authentication/login_with_xbox",
            buildJsonObject { put("identityToken", "XBL3.0 x=$uhs;$xstsToken") })
        val mcToken = mc["access_token"]!!.jsonPrimitive.content

        val req = Request.Builder().url("https://api.minecraftservices.com/minecraft/profile")
            .header("Authorization", "Bearer $mcToken").build()
        MojangApi.http.newCall(req).execute().use { r ->
            check(r.code != 404) { "This Microsoft account doesn't own Minecraft: Java Edition" }
            check(r.isSuccessful) { "Profile HTTP ${r.code}" }
            val p = Json.parseToJsonElement(r.body!!.string()).jsonObject
            return McSession(p["name"]!!.jsonPrimitive.content, p["id"]!!.jsonPrimitive.content, mcToken, refresh)
        }
    }
}
