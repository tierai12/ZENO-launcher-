package dev.launcher.core

import kotlinx.serialization.json.Json
import okhttp3.OkHttpClient
import okhttp3.Request

object MojangApi {
    val http = OkHttpClient()
    val json = Json { ignoreUnknownKeys = true; isLenient = true }
    private const val MANIFEST = "https://piston-meta.mojang.com/mc/game/version_manifest_v2.json"

    fun getText(url: String): String {
        http.newCall(Request.Builder().url(url).build()).execute().use { r ->
            check(r.isSuccessful) { "HTTP ${r.code} for $url" }
            return r.body!!.string()
        }
    }

    fun manifest(): VersionManifest = json.decodeFromString(getText(MANIFEST))

    /** Returns the parsed version plus its raw JSON (saved to disk for the launch step). */
    fun versionJson(url: String): Pair<VersionJson, String> {
        val raw = getText(url)
        return json.decodeFromString<VersionJson>(raw) to raw
    }

    fun assetIndex(ref: AssetIndexRef): Pair<AssetIndex, String> {
        val raw = getText(ref.url)
        return json.decodeFromString<AssetIndex>(raw) to raw
    }
}
