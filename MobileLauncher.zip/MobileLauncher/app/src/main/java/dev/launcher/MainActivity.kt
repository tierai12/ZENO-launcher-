package dev.launcher

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.unit.dp
import dev.launcher.auth.*
import dev.launcher.core.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.io.File

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = File(filesDir, "minecraft")
        setContent { MaterialTheme { Surface { LauncherScreen(root) } } }
    }
}

@Composable
fun LauncherScreen(root: File) {
    val scope = rememberCoroutineScope()
    val uri = LocalUriHandler.current
    var status by remember { mutableStateOf("Not signed in") }
    var code by remember { mutableStateOf<DeviceCode?>(null) }
    var session by remember { mutableStateOf<McSession?>(null) }
    var versions by remember { mutableStateOf<List<VersionEntry>>(emptyList()) }
    var selected by remember { mutableStateOf<VersionEntry?>(null) }
    var progress by remember { mutableStateOf(0f) }
    var busy by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        scope.launch(Dispatchers.IO) {
            runCatching { MojangApi.manifest() }
                .onSuccess { m -> versions = m.versions.filter { it.type == "release" }; selected = versions.firstOrNull() }
                .onFailure { status = "Couldn't load versions: ${it.message}" }
        }
    }

    Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Launcher", style = MaterialTheme.typography.headlineMedium)
        Text(session?.let { "Signed in as ${it.name}" } ?: status)

        if (session == null) {
            Button(onClick = {
                scope.launch(Dispatchers.IO) {
                    runCatching {
                        val dc = MicrosoftAuth.requestDeviceCode(); code = dc
                        status = "Enter the code on the Microsoft page"
                        session = MicrosoftAuth.signIn(dc)
                    }.onFailure { status = it.message ?: "Sign-in failed" }
                }
            }) { Text("Sign in with Microsoft") }
            code?.let { c ->
                Text("Code: ${c.userCode}", style = MaterialTheme.typography.titleLarge)
                OutlinedButton(onClick = { uri.openUri(c.verificationUri) }) { Text("Open ${c.verificationUri}") }
            }
        }

        Text("Version: ${selected?.id ?: "loading…"}")
        LazyColumn(Modifier.height(180.dp)) {
            items(versions) { v -> Text(v.id, Modifier.fillMaxWidth().clickable { selected = v }.padding(8.dp)) }
        }

        Button(enabled = !busy && selected != null, onClick = {
            busy = true; progress = 0f; status = "Downloading…"
            scope.launch(Dispatchers.IO) {
                runCatching { Downloader(root).install(selected!!) { progress = it } }
                    .onSuccess { status = "Installed ${selected!!.id}" }
                    .onFailure { status = "Download failed: ${it.message}" }
                busy = false
            }
        }) { Text("Download") }
        if (busy || progress > 0f) LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth())

        Button(enabled = false, onClick = {}) { Text("Play (next milestone: JVM + renderer)") }
    }
}
