package dev.launcher.core

import kotlinx.serialization.Serializable
import kotlinx.serialization.json.JsonElement

@Serializable data class VersionManifest(val latest: Latest, val versions: List<VersionEntry>)
@Serializable data class Latest(val release: String, val snapshot: String)
@Serializable data class VersionEntry(val id: String, val type: String, val url: String)

@Serializable data class VersionJson(
    val id: String,
    val mainClass: String,
    val assetIndex: AssetIndexRef,
    val downloads: Downloads,
    val libraries: List<Library>,
    val javaVersion: JavaVersion? = null,
    val arguments: Arguments? = null,
    val minecraftArguments: String? = null,
)
@Serializable data class AssetIndexRef(val id: String, val sha1: String, val size: Long, val url: String)
@Serializable data class Downloads(val client: Artifact)
@Serializable data class Artifact(val path: String? = null, val sha1: String, val size: Long, val url: String)
@Serializable data class Library(val name: String, val downloads: LibDownloads? = null, val rules: List<Rule>? = null)
@Serializable data class LibDownloads(val artifact: Artifact? = null)
@Serializable data class Rule(val action: String, val os: OsRule? = null)
@Serializable data class OsRule(val name: String? = null, val arch: String? = null)
@Serializable data class JavaVersion(val component: String, val majorVersion: Int)
@Serializable data class Arguments(val game: List<JsonElement> = emptyList(), val jvm: List<JsonElement> = emptyList())
@Serializable data class AssetIndex(val objects: Map<String, AssetObject>)
@Serializable data class AssetObject(val hash: String, val size: Long)

/**
 * Evaluates Mojang library rules as if running on generic Linux.
 * Rules carrying an arch constraint are treated as non-matching.
 */
fun Library.applies(): Boolean {
    val r = rules ?: return true
    var allowed = false
    for (rule in r) {
        val o = rule.os
        val match = o == null || ((o.name == null || o.name == "linux") && o.arch == null)
        if (match) allowed = rule.action == "allow"
    }
    return allowed
}
