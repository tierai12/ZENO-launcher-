package dev.launcher.core

import kotlinx.coroutines.*
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import okhttp3.Request
import java.io.File
import java.security.MessageDigest
import java.util.concurrent.atomic.AtomicLong

private data class Task(val url: String, val sha1: String, val size: Long, val dest: File)

/**
 * Layout (same as the official launcher):
 *   versions/<id>/<id>.json + <id>.jar
 *   libraries/<maven path>
 *   assets/indexes/<id>.json, assets/objects/<xx>/<hash>
 *
 * LWJGL libraries are skipped by default: desktop LWJGL natives won't run on
 * Android, so your own Android-built LWJGL + GLFW shim replaces them.
 */
class Downloader(private val root: File, private val skipLwjgl: Boolean = true) {

    suspend fun install(entry: VersionEntry, onProgress: (Float) -> Unit) = withContext(Dispatchers.IO) {
        val (vj, raw) = MojangApi.versionJson(entry.url)
        val vdir = File(root, "versions/${vj.id}").apply { mkdirs() }
        File(vdir, "${vj.id}.json").writeText(raw)

        val (index, indexRaw) = MojangApi.assetIndex(vj.assetIndex)
        File(root, "assets/indexes").mkdirs()
        File(root, "assets/indexes/${vj.assetIndex.id}.json").writeText(indexRaw)

        val tasks = mutableListOf<Task>()
        vj.downloads.client.let { tasks += Task(it.url, it.sha1, it.size, File(vdir, "${vj.id}.jar")) }
        vj.libraries
            .filter { it.applies() && !(skipLwjgl && it.name.startsWith("org.lwjgl")) }
            .mapNotNull { it.downloads?.artifact }
            .forEach { a -> tasks += Task(a.url, a.sha1, a.size, File(root, "libraries/${a.path}")) }
        index.objects.values.distinctBy { it.hash }.forEach { o ->
            val p = o.hash.substring(0, 2)
            tasks += Task("https://resources.download.minecraft.net/$p/${o.hash}", o.hash, o.size, File(root, "assets/objects/$p/${o.hash}"))
        }

        val total = tasks.sumOf { it.size }.coerceAtLeast(1)
        val done = AtomicLong(0)
        val gate = Semaphore(8)
        coroutineScope {
            tasks.map { t ->
                async {
                    gate.withPermit { fetch(t) }
                    onProgress(done.addAndGet(t.size).toFloat() / total)
                }
            }.awaitAll()
        }
        onProgress(1f)
    }

    private fun fetch(t: Task) {
        if (t.dest.exists() && sha1(t.dest) == t.sha1) return
        t.dest.parentFile?.mkdirs()
        repeat(3) { attempt ->
            try {
                MojangApi.http.newCall(Request.Builder().url(t.url).build()).execute().use { r ->
                    check(r.isSuccessful) { "HTTP ${r.code}" }
                    val tmp = File(t.dest.path + ".part")
                    r.body!!.byteStream().use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }
                    check(sha1(tmp) == t.sha1) { "SHA-1 mismatch" }
                    tmp.renameTo(t.dest)
                    return
                }
            } catch (e: Exception) {
                if (attempt == 2) throw RuntimeException("Failed ${t.url}: ${e.message}", e)
            }
        }
    }

    private fun sha1(f: File): String {
        val md = MessageDigest.getInstance("SHA-1")
        f.inputStream().use { s -> val b = ByteArray(65536); while (true) { val n = s.read(b); if (n < 0) break; md.update(b, 0, n) } }
        return md.digest().joinToString("") { "%02x".format(it) }
    }
}
